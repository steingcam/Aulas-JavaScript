class Pessoa {
    constructor(nome, sobrenome){
        this.nome = nome;
        this.sobrenome = sobrenome;
    }
}

class Carro {
    constructor(modelo){
        this.marca = 'Honda';
        this.modelo = modelo;
    }
}
