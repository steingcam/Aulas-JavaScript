class Pessoa {

}

class Carro {

}


