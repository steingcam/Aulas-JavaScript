console.log(somar(4, 6)); 


// Forma literal
function somar(n1, n2){
    return n1 + n2;
}


// let somar = function(v1, v2){
//     return v1+ v2;
// }
